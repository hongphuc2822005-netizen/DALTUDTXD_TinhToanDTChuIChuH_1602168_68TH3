﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DALTUDTXD_TinhToanDTChuIChuH_1602168_68TH3.Views
{
    /// <summary>
    /// Interaction logic for BeamView.xaml
    /// </summary>
    public partial class BeamView : Window
    {
        public BeamView()
        {
            InitializeComponent();
            DataContext = new ViewModels.BeamViewModel();
        }
    }
}
