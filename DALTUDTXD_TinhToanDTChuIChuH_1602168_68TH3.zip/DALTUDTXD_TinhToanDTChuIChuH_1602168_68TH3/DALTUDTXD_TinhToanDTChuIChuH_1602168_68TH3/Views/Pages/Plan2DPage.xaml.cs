﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DALTUDTXD_TinhToanDTChuIChuH_1602168_68TH3.Views.Pages
{
    /// <summary>
    /// Interaction logic for Plan2DPage.xaml
    /// </summary>
    public partial class Plan2DPage : Page
    {
        public Plan2DPage()
        {
            InitializeComponent();
        }
    }
}
